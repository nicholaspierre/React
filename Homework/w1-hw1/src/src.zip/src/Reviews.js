import React from 'react'

const Reviews = () => {
    return (
        <div className="Reviews">Reviews</div>
    )
}

export default Reviews