import React from 'react'

const Sidebar = () => {
    return (
        <div className="LeftPanel"> Sidebar</div >
    )
}

export default Sidebar