import React from 'react'
import './styles.css'
import Sidebar from './sidebar'
import Reviews from './Reviews'
import Rating from './Rating'
import Analysis from './Analysis'
import WebsiteVisotrs from './WebsiteVisitors'


const App = () => {
    return (
        <div className="body">
            <Sidebar />
            <Reviews />
            <Rating />
            <Analysis />
            <WebsiteVisotrs />
        </div>
    )
}

export default App