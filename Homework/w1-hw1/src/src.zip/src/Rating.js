import React from 'react'


const Rating = () => {
    return (
        <div className="AvgRating">Average Rating</div>
    )
}

export default Rating