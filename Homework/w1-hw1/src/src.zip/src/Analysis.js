import React from 'react'

const Analysis = () => {
    return (
        <div className="Analysis">Analysis</div>
    )
}

export default Analysis